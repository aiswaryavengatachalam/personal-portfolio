const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/projects", (req, res) => {
  res.json([
    {
      title: "Personal Portfolio Website",
      description: "A responsive portfolio website to showcase profile, skills and projects."
    },
    {
      title: "E-Governance Data Analysis",
      description: "A project focused on analysis of digital government service data."
    }
  ]);
});

app.listen(PORT, () => {
  console.log(`Portfolio running at http://localhost:${PORT}`);
});
