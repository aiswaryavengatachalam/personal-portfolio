document.addEventListener("DOMContentLoaded", () => {
  console.log("Personal Portfolio loaded successfully.");
});
