# Personal Portfolio Website

A full-stack personal portfolio website created using HTML, CSS, JavaScript and Node.js/Express.

## Features
- Home section
- About section
- Skills section
- Projects section
- Contact section
- Responsive design
- Express.js backend
- Sample projects API

## Technologies
- HTML5
- CSS3
- JavaScript
- Node.js
- Express.js

## Run locally
1. Install Node.js.
2. Open this project folder in a terminal.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## GitHub Submission
Upload the complete project folder to a public GitHub repository named `personal-portfolio`.
